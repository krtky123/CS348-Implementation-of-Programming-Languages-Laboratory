/*
	Kartikay Goel, 180101033
*/

#include <bits/stdc++.h>
using namespace std;

extern int yyparse(void);

vector<string> errorMessage; // vector of error messages
char* err; // a temporary variable to store new error

extern FILE* yyin; // input file to lexer

vector<string> reservedKeywords = {"PROGRAM","VAR","BEGIN","END","END.","INTEGER","REAL","FOR","READ","WRITE","TO","DO","DIV"}; // this vector contains reserved keywords

int main()
{
	FILE* fptr = fopen("180101033_input.txt","r"); // open the input file
	
	yyin = fptr; // assign the lexer input to the file opened
	
	err = (char *)malloc(sizeof(char)*256); // allocate space for the err variable

	err[0] = '\0'; // initialize the err variable

	cout<<"Compilation Begin"<<endl;

	if(!yyparse())
	{
		cout<<"Parse Successful"<<endl;
		// All the statements written in the input follow the grammar
	}
	else
	{
		cout<<"Parse Unsuccessful"<<endl;
	}

	cout << "Compilation End"<< endl;

	fclose(fptr); // Close the input file

	if(!errorMessage.size())
	{ 
		cout<<"No syntax or sematic errors found!"<<endl;
	}
	else
	{
		// If there are error messages then print them to terminal
		cout<<"Following errors were found:"<<endl;
		int i=0;
		while(i<errorMessage.size())
		{
			cout<<errorMessage[i]<<endl;
			i++;
		}
	}
	return 0;
}